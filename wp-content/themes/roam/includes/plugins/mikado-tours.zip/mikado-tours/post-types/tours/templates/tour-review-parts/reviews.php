<?php
mkdf_tours_reviews_print_ratings_display();

comments_template('', true);