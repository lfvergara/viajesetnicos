<?php

include_once MIKADO_TOURS_CPT_PATH . '/tours/tours-register.php';
include_once MIKADO_TOURS_CPT_PATH . '/tours/helper-functions.php';
include_once MIKADO_TOURS_CPT_PATH . '/tours/tax-custom-fields.php';
include_once MIKADO_TOURS_CPT_PATH . '/tours/shortcodes/shortcodes-functions.php';
include_once MIKADO_TOURS_CPT_PATH . '/tours/reviews/load.php';