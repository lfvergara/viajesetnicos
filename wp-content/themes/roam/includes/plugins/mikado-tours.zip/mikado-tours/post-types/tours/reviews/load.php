<?php

define('MIKADO_TOURS_REVIEWS_PREFIX', 'mkdf_tours_reviews_');
define('MIKADO_TOURS_REVIEWS_MAX_RATING', 5);
define('MIKADO_TOURS_REVIEWS_POINTS_SCALE', 2);

require_once 'functions.php';
require_once 'tax-custom-fields.php';