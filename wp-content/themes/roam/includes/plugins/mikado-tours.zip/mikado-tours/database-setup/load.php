<?php

require_once 'database-table-setup.php';
require_once 'tour-dates-table-setup.php';
require_once 'tour-times-table-setup.php';
require_once 'tour-bookings-table-setup.php';
require_once 'review-ratings-table-setup.php';
require_once 'tables-setup.php';