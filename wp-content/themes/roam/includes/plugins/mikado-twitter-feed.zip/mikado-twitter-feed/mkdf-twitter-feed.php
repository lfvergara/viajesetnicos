<?php
/*
Plugin Name: Mikado Twitter Feed
Description: Plugin that adds Twitter feed functionality to our theme
Author: Mikado Themes
Version: 1.0
*/
define('MIKADO_TWITTER_FEED_VERSION', '1.0');

include_once 'load.php';