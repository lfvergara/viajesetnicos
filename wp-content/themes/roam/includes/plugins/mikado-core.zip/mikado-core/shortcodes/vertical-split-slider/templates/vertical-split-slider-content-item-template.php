<div class="mkdf-vss-ms-section" <?php echo roam_mikado_get_inline_attrs($content_data); ?> <?php roam_mikado_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>