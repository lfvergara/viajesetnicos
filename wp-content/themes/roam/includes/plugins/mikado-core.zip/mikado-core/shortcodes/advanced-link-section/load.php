<?php

include_once MIKADO_CORE_SHORTCODES_PATH . '/advanced-link-section/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH . '/advanced-link-section/advanced-link-section.php';