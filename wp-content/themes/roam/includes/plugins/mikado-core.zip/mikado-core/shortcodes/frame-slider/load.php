<?php

include_once MIKADO_CORE_SHORTCODES_PATH . '/frame-slider/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH . '/frame-slider/frame-slider.php';