<div class="mkdf-team-single-content">
    <h4 class="mkdf-team-single-content-title"><?php esc_html_e('About','mkdf-core')?></h4>
	<?php the_content(); ?>
</div>